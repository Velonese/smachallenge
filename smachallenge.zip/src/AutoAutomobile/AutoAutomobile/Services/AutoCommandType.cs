﻿namespace AutoAutomobile
{
    public enum AutoCommandType
    {
        Accelerate,
        Brake,
        IgnitionOn,
        IgnitionOff,
        Delay,
    }
}